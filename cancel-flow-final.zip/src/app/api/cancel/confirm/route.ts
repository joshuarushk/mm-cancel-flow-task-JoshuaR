import { NextRequest } from 'next/server'
import { supabaseAdmin } from '@/src/lib/supabase'
import { assertCsrf } from '@/src/lib/csrf'

export async function POST(req: NextRequest) {
  assertCsrf()
  const { user_id } = await req.json()
  if (!user_id || typeof user_id !== 'string') return new Response('Invalid user', { status: 400 })

  // Find pending cancellation
  const { data: pending, error } = await supabaseAdmin
    .from('cancellations')
    .select('*')
    .eq('user_id', user_id)
    .eq('status','pending')
    .order('created_at', { ascending: false })
    .limit(1)
  if (error || !pending || pending.length === 0) return new Response('Not found', { status: 404 })

  // Mark cancellation confirmed
  const { error: updCanc } = await supabaseAdmin
    .from('cancellations')
    .update({ status: 'confirmed', accepted_downsell: false })
    .eq('id', pending[0].id)
  if (updCanc) return new Response(updCanc.message, { status: 500 })

  // Mark subscription canceled
  const { error: updSub } = await supabaseAdmin
    .from('subscriptions')
    .update({ status: 'canceled', pending_cancellation: false })
    .eq('user_id', user_id)
    .eq('status','active')
  if (updSub) return new Response(updSub.message, { status: 500 })

  return new Response(null, { status: 204 })
}
