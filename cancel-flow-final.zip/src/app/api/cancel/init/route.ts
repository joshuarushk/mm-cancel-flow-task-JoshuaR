import { NextRequest } from 'next/server'
import { supabase, supabaseAdmin } from '@/src/lib/supabase'
import { assertCsrf } from '@/src/lib/csrf'

import crypto from 'node:crypto'

function getVariantFromPriceCents(cents: number): 'A'|'B' {
  // Secure RNG: Node crypto for deterministic 50/50 split
  const b = crypto.randomBytes(1)[0]
  return (b & 1) === 0 ? 'A' : 'B'
}
  return Math.random() < 0.5 ? 'A' : 'B'
}

export async function POST(req: NextRequest) {
  assertCsrf()
  const { user_id } = await req.json()
  if (!user_id || typeof user_id !== 'string') {
    return new Response('Invalid user_id', { status: 400 })
  }

  // Ensure there is an active subscription
  const { data: sub, error: subErr } = await supabaseAdmin
    .from('subscriptions')
    .select('*')
    .eq('user_id', user_id)
    .eq('status','active')
    .single()
  if (subErr || !sub) {
    return new Response('No active subscription', { status: 404 })
  }

  // Check existing pending cancellation (for variant reuse)
  const { data: existing, error: existingErr } = await supabaseAdmin
    .from('cancellations')
    .select('*')
    .eq('user_id', user_id)
    .eq('status','pending')
    .order('created_at', { ascending: false })
    .limit(1)
  if (existingErr) {
    return new Response(existingErr.message, { status: 500 })
  }
  let variant: 'A'|'B'
  if (existing && existing.length > 0) {
    variant = existing[0].downsell_variant
  } else {
    variant = getVariantFromPriceCents(sub.monthly_price)
    const { error: insErr } = await supabaseAdmin
      .from('cancellations')
      .insert({ user_id, downsell_variant: variant, status: 'pending' })
    if (insErr) return new Response(insErr.message, { status: 500 })
  }

  // Mark subscription as pending_cancellation (idempotent)
  const { error: updErr } = await supabaseAdmin
    .from('subscriptions')
    .update({ pending_cancellation: true })
    .eq('id', sub.id)
  if (updErr) return new Response(updErr.message, { status: 500 })

  return Response.json({ variant, monthly_price: sub.monthly_price, subscription_id: sub.id })
}
