import { NextRequest } from 'next/server'
import { supabaseAdmin } from '@/src/lib/supabase'
import { assertCsrf } from '@/src/lib/csrf'

export async function POST(req: NextRequest) {
  assertCsrf()
  const body = await req.json()
  const { user_id, reason } = body || {}
  if (!user_id || typeof user_id !== 'string') return new Response('Invalid user', { status: 400 })
  if (typeof reason !== 'string' || reason.length < 2 || reason.length > 500) {
    return new Response('Invalid reason', { status: 400 })
  }

  const { data: pending, error } = await supabaseAdmin
    .from('cancellations')
    .select('*')
    .eq('user_id', user_id)
    .eq('status','pending')
    .order('created_at', { ascending: false })
    .limit(1)
  if (error || !pending || pending.length === 0) {
    return new Response('No pending cancellation', { status: 404 })
  }

  const { error: updErr } = await supabaseAdmin
    .from('cancellations')
    .update({ reason })
    .eq('id', pending[0].id)
  if (updErr) return new Response(updErr.message, { status: 500 })

  return new Response(null, { status: 204 })
}
