import { NextRequest } from 'next/server'
import { supabaseAdmin } from '@/src/lib/supabase'
import { assertCsrf } from '@/src/lib/csrf'

export async function POST(req: NextRequest) {
  assertCsrf()
  const { user_id } = await req.json()
  if (!user_id || typeof user_id !== 'string') return new Response('Invalid user', { status: 400 })

  const { data: pending, error } = await supabaseAdmin
    .from('cancellations')
    .select('*')
    .eq('user_id', user_id)
    .eq('status','pending')
    .order('created_at', { ascending: false })
    .limit(1)
  if (error || !pending || pending.length === 0) return new Response('Not found', { status: 404 })

  const { error: upd } = await supabaseAdmin
    .from('cancellations')
    .update({ accepted_downsell: true })
    .eq('id', pending[0].id)
  if (upd) return new Response(upd.message, { status: 500 })

  // Reset pending_cancellation on subscription because they stayed
  const { error: subUpd } = await supabaseAdmin
    .from('subscriptions')
    .update({ pending_cancellation: false })
    .eq('user_id', user_id)
    .eq('status','active')
  if (subUpd) return new Response(subUpd.message, { status: 500 })

  return new Response(null, { status: 204 })
}
